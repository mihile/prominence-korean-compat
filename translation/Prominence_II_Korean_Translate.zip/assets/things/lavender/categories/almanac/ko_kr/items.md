```json
{
  "icon": "things:bater_wucket",
  "title": "아이템"
}
```

일반 아이템의 사용법을 안내합니다.
