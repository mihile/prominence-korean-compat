```json
{
  "icon": "things:moss_necklace",
  "title": "장신구"
}
```

모든 장신구의 사용법을 안내합니다.
