```json
{
  "icon": "things:monocle",
  "title": "단안경",
  "category": "things:trinkets",
  "associated_items": [
    "things:monocle"
  ]
}
```

단안경은 오래전부터 시야를 개선하는 데 사용되었습니다. 렌즈에 {light_purple}반짝이는 가루{}를 더하면 마법의 빛이 깃들어, 착용자에게 {gold}야간 투시{} 효과까지 제공합니다.

;;;;;

<recipe;things:monocle>
