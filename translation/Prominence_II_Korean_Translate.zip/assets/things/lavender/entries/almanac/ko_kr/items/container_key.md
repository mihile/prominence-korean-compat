```json
{
  "icon": "things:container_key",
  "title": "컨테이너 열쇠",
  "category": "things:items",
  "associated_items": [
    "things:container_key"
  ]
}
```

{light_purple}컨테이너 열쇠{}는 소지품을 안전하게 보관하고 싶을 때 유용합니다. 상자나 화로 같은 보관함에 {gold}Shift+우클릭{}하면 잠글 수 있습니다. 잠금을 해제하기 전까지는 잠글 때 사용한 {gold}바로 그 열쇠{}로만 열 수 있습니다. 같은 열쇠로 다시 {gold}Shift+우클릭{}하면 잠금이 해제됩니다.

;;;;;

<recipe;things:container_key>

다만 보관함 자체를 부수면 쉽게 우회할 수 있으므로, 완벽한 도난 방지 수단은 아닙니다.
