```json
{
  "icon": "things:moss_necklace",
  "title": "이끼 낀 목걸이",
  "category": "things:trinkets",
  "associated_items": [
    "things:moss_necklace"
  ]
}
```

상처를 처치하는 일은 번거롭지만, {light_purple}이끼 낀 목걸이{}가 대신해 줍니다. 햇빛이든 인공 조명이든 빛을 받으면 착용자를 치유하기 시작합니다. 아주 위생적인 방법은 아니지만, 자라난 이끼가 상처를 메워 줍니다.

;;;;;

<recipe;things:moss_necklace>

*{#999999}“천연” 반창고{}*
