```json
{
  "icon": "things:hardening_catalyst",
  "title": "경화 촉매제",
  "category": "things:items",
  "associated_items": [
    "things:hardening_catalyst"
  ]
}
```

{light_purple}네더의 별{}과 여러 단단한 재료를 섞으면 뜻밖에도 액체가 만들어집니다. 이 액체에는 흥미로운 성질이 있습니다. {gold}모루{}에서 내구도가 있는 아이템에 사용하면 경험치를 소모해 그 아이템이 {gold}부서지지 않게{} 만들 수 있습니다.

;;;;;

<recipe;things:hardening_catalyst>
