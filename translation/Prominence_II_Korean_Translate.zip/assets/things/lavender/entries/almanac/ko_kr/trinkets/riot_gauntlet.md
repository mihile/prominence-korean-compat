```json
{
  "icon": "things:riot_gauntlet",
  "title": "폭동 건틀릿",
  "category": "things:trinkets",
  "associated_items": [
    "things:riot_gauntlet"
  ]
}
```

{light_purple}반짝이는 혼합물{}의 마법과 {light_purple}네더라이트 주괴{} 두 개의 묵직함을 결합한 {light_purple}폭동 건틀릿{}은 착용자의 힘을 크게 높여 줍니다. 무기 없이도 좀비 한 마리쯤은 손쉽게 해치울 수 있어, 전사의 든든한 동반자가 됩니다.

;;;;;

<recipe;things:riot_gauntlet>
