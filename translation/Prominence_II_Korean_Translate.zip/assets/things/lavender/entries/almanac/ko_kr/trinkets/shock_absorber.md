```json
{
  "icon": "things:shock_absorber",
  "title": "충격 흡수기",
  "category": "things:trinkets",
  "associated_items": [
    "things:shock_absorber"
  ]
}
```

빠른 속도로 벽에 부딪히거나 땅에 떨어지면 몹시 아픕니다. {light_purple}충격 흡수기{}는 이러한 충격을 줄여 줍니다. 주로 {light_purple}팬텀 막{}과 {light_purple}양털{}을 [반짝이는 혼합물](^things:items/gleaming_materials)로 결합한 멋진 신발로, {gold}낙하 피해를 줄이고, 운동 에너지 피해를 75% 줄여 줍니다{}.

;;;;;

<recipe;things:shock_absorber>
