```json
{
  "icon": "things:diamond_pressure_plate",
  "title": "다이아몬드 압력판",
  "associated_items": [
    "things:diamond_pressure_plate"
  ]
}
```

{light_purple}다이아몬드{}로 만든 압력판은 흔하지 않지만 유용합니다. {gold}플레이어에게만 반응{}하므로, 현관문 바깥에 설치하기에 적합합니다.

;;;;;

<recipe;things:diamond_pressure_plate>
