```json
{
  "icon": "things:hades_crystal",
  "title": "하데스 수정",
  "category": "things:trinkets",
  "associated_items": [
    "things:hades_crystal"
  ]
}
```

네더의 뜨거운 열기를 {light_purple}반짝이는 혼합물{}에 직접 가하면 {light_purple}하데스 수정{}이 만들어집니다. 이렇게 변한 혼합물은 열을 흡수하고 중화하는 성질을 얻어, 온갖 불길로부터 착용자를 보호합니다.

;;;;;

<recipe;things:hades_crystal>
