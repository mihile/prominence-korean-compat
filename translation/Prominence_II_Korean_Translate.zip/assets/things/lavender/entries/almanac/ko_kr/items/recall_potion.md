```json
{
  "icon": "things:recall_potion",
  "title": "귀환의 물약",
  "category": "things:items",
  "associated_items": [
    "things:recall_potion"
  ]
}
```

Minecraft만큼이나 오래된 발상일지도 모르는 {light_purple}귀환의 물약{}은 사용자를 즉시 {gold}생성 지점{}으로 돌려보냅니다. 정체 모를 아공간의 작용을 이용하지만, 정확한 원리는 아직 밝혀지지 않았습니다. {light_purple}어색한 물약{}에 {light_purple}엔더 진주{}의 힘을 더해 {gold}양조기{}에서 만들 수 있습니다.
