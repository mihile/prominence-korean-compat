```json
{
  "icon": "things:gleaming_powder",
  "title": "반짝이는 재료",
  "associated_items": [
    "things:gleaming_powder",
    "things:gleaming_compound"
  ]
}
```

{light_purple}반짝이는 가루{}는 [반짝이는 광석](^things:gleaming_ore)에서 얻으며, 유용한 마법의 성질을 지니고 있습니다. 어떤 사람들은 원시적인 생명체로 여기기도 합니다. 가루만으로는 별 쓸모가 없지만, 다양한 도구와 장신구를 만드는 데 사용됩니다.

;;;;;

<recipe;things:gleaming_compound>

{light_purple}다이아몬드{}를 가루로 덮으면 더 강력한 {light_purple}반짝이는 혼합물{}을 만들 수 있습니다.
