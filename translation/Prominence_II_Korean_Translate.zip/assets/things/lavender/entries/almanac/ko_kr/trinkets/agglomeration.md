```json
{
  "icon": "things:agglomeration",
  "title": "응집체",
  "category": "things:trinkets",
  "associated_items": [
    "things:empty_agglomeration",
    "things:agglomeration"
  ]
}
```

장신구를 모으다 보면 같은 슬롯을 사용하는 장신구 중 하나를 골라야 할 때가 있습니다. 한 슬롯에 두 개를 착용할 수 있다면 얼마나 좋을까요? {light_purple}응집체{}가 바로 그 역할을 합니다.

먼저 다음 제작법에 따라 준비합니다.

;;;;;

<recipe;things:empty_agglomeration>

위와 같이 {light_purple}빈 응집체{}를 만든 뒤 원하는 장신구 두 개와 결합합니다. 두 장신구는 {gold}사용할 수 있는 슬롯이 적어도 하나는 같아야 합니다{}.

결합할 장신구는 신중히 골라야 합니다.

;;;;;

한번 결합한 장신구는 다시 분리할 수 없습니다.
