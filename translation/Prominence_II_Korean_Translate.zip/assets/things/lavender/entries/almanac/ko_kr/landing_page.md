```json
{
  "title": "Things 안내서"
}
```

{gold}Things{}는 여러 유용한 물건을 추가하는 모드입니다.

먼저 동굴에서 [반짝이는 가루](^things:gleaming_ore)를 구해 보세요. 대부분의 {gold}Things 아이템{}을 만드는 데 꼭 필요한 재료입니다.

문제가 생기거나 버그를 발견하면 [Wisp Forest Discord](https://discord.com/invite/xrwHKktV2d)에 문의하거나 [GitHub](https://github.com/wisp-forest/things/issues)에 제보할 수 있습니다.
