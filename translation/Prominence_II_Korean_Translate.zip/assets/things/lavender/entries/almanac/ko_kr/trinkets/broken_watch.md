```json
{
  "icon": "things:broken_watch",
  "title": "고장난 시계",
  "category": "things:trinkets",
  "associated_items": [
    "things:broken_watch"
  ]
}
```

{light_purple}고장난 시계{}가 쓸모없다고 생각할 만도 합니다. 하지만 [반짝이는 혼합물](^things:items/gleaming_materials)로 보존하면 현재 적용된 {gold}물약 효과{}에 이로운 영향을 줍니다. {gold}지속 시간이 50% 늘어납니다{}. {light_purple}시계{}를 부수려면 엄청난 힘이 필요하므로, {gold}제작대{}로는 만들 수 없습니다.

;;;;;

대신 {light_purple}가죽{}, {light_purple}시계{}, {gold}반짝이는 혼합물{}을 바닥에 던집니다.

![](things:textures/gui/watch_patchouli.png,fit)

;;;;;

그다음 {gold}피스톤으로 눌러 부수면 됩니다{}.
