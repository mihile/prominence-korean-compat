```json
{
  "icon": "things:luck_of_the_irish",
  "title": "아일랜드인의 행운",
  "category": "things:trinkets",
  "associated_items": [
    "things:luck_of_the_irish"
  ]
}
```

대부분의 플레이어에게 {light_purple}독이 있는 감자{}는 쓸모없는 부산물처럼 보입니다. 하지만 {light_purple}아일랜드인의 행운{}을 만들어 착용하면 이야기가 달라집니다. 여기에 들어 있는 {light_purple}반짝이는 혼합물{}은 평소 받던 독 효과를 {gold}재생 II{}로 바꿔 줍니다.

;;;;;

<recipe;things:luck_of_the_irish>

함께 사용된 {light_purple}마법이 부여된 황금 사과{}에서 얻은 지식을 활용하는 것입니다.
