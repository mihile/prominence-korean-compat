```json
{
  "icon": "things:bater_wucket",
  "title": "양동물이",
  "category": "things:items",
  "associated_items": [
    "things:bater_wucket"
  ]
}
```

전설에 따르면 Reddit이라는 오래된 세계에는 유난히 기묘한 사람들이 살았다고 합니다. 어느 날 그곳에서 물 양동이를 뒤집은 듯한 {light_purple}양동물이{}라는 발상이 나왔고, 이를 본 사람들은 모두 경악했다고 합니다.

;;;;;

<recipe;things:bater_wucket>

이 저주받은 도구는 순수한 물을 정체 모를 무언가로 뭉쳐 만든 것으로, 거의 무한히 물을 쏟아낼 수 있다고 합니다.

*{#999999}…뭐라고요?{}*
