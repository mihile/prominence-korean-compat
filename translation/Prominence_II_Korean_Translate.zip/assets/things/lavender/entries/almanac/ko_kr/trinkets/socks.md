```json
{
  "icon": "things:socks",
  "title": "양말",
  "category": "things:trinkets",
  "associated_items": [
    "things:socks"
  ]
}
```

멋쟁이라면 양말 한 켤레쯤은 있어야 합니다. {light_purple}양털{}에 [반짝이는 가루](^things:items/gleaming_materials)를 더하면 쉽게 만들 수 있으며, 착용하면 즉시 {gold}이동 속도가 증가{}합니다. 더 빠르게 움직이고 싶다면 제작대에서 {light_purple}양말{}에 {gold}강력한 신속의 물약{}과 [반짝이는 가루](^things:items/gleaming_materials)를 추가할 수 있습니다.

;;;;;

<recipe;things:socks>

{light_purple}토끼발 부적{}을 결합할 수도 있습니다. 이때 {light_purple}반짝이는 혼합물{} 하나가 소모됩니다. 그러면 {gold}점프 강화 II{}와 {gold}단차 자동 오르기{} 기능이 생깁니다. {light_purple}점프 강화{}는 <keybind;key.things.toggle_socks_jump_boost> 키로 켜거나 끌 수 있습니다.
