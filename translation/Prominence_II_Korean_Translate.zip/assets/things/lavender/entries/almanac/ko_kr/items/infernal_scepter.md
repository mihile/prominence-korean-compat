```json
{
  "icon": "things:infernal_scepter",
  "title": "지옥의 홀",
  "category": "things:items",
  "associated_items": [
    "things:infernal_scepter"
  ]
}
```

{light_purple}용암 양동이{}를 {light_purple}블레이즈 막대{}에 붙이고 {light_purple}네더라이트 주괴{}로 보강하면 어떨까요? 적어도 무기로는 훌륭합니다! {light_purple}화염구{}를 가열하는 {light_purple}지옥의 홀{}은 뜨겁고 치명적인 투사체를 발사합니다. 다만 이 과정에서 무기에 가해지는 부담도 상당합니다.

;;;;;

<recipe;things:infernal_scepter>

아무리 튼튼한 네더라이트라도 영원히 버틸 수는 없습니다.
