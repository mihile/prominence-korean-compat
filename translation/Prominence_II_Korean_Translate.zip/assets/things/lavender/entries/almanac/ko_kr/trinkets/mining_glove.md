```json
{
  "icon": "things:mining_gloves",
  "title": "채굴 장갑",
  "category": "things:trinkets",
  "associated_items": [
    "things:mining_gloves"
  ]
}
```

채굴은 Minecraft의 핵심 활동이지만, 대량으로 하려면 제법 힘이 듭니다. {light_purple}채굴 장갑{}은 손을 더 튼튼하고 민첩하게 만들어 채굴 속도를 크게 높여 줍니다.

;;;;;

<recipe;things:mining_gloves>
