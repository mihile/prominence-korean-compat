```json
{
  "icon": "things:placebo",
  "title": "플라시보",
  "category": "things:trinkets",
  "associated_items": [
    "things:placebo"
  ]
}
```

물약을 대량으로 만드는 일이 아주 어렵지는 않더라도, 조금이라도 아끼면 도움이 됩니다. {light_purple}플라시보{}는 가끔 사용자가 마시는 물약을 몰래 가짜로 바꿉니다. 그런데도 물약의 효과는 그대로 유지됩니다.

;;;;;

<recipe;things:placebo>

어떤 원리인지는 아직 모릅니다. 그냥 됩니다.
