```json
{
  "icon": "things:displacement_tome",
  "title": "전위의 고서",
  "category": "things:items",
  "associated_items": [
    "things:displacement_tome",
    "things:displacement_page"
  ]
}
```

{light_purple}발광 먹물{}의 특성을 이용하면 {light_purple}엔더 진주{}로 사용자를 {light_purple}전위의 페이지{}에 기록된 위치까지 이동시킬 수 있습니다. 다만 페이지는 너무 약해서 단독으로 사용할 수 없으므로 {light_purple}전위의 고서{}에 넣어야 합니다. 이 고서는 페이지에 위치를 기록할 때도 사용합니다.

;;;;;

{light_purple}전위의 페이지{}를 하나 이상 가진 상태에서 고서를 열고 {gold}+{} 버튼을 누르면 새 항목이 만들어지며 페이지가 삽입됩니다. 항목을 {gold}우클릭{}하면 내용을 수정하거나 페이지를 버릴 수 있습니다. 고서에는 {light_purple}엔더 진주{}를 저장하는 공간도 있습니다. 고서를 {gold}우클릭{}해 인벤토리의 {light_purple}엔더 진주{}로 충전할 수 있습니다.

;;;;;

<recipe;things:displacement_tome>

;;;;;

<recipe;things:displacement_page>
