```json
{
  "icon": "things:enchanted_wax_gland",
  "title": "마법이 깃든 밀랍샘",
  "category": "things:trinkets",
  "associated_items": [
    "things:enchanted_wax_gland"
  ]
}
```

{light_purple}밀랍샘{}을 발에 달면 의외로 유용합니다. 자연에서 볼 수 있는 것처럼, 하반신을 밀랍으로 덮으면 물에 뜹니다. 여기에 섞인 {light_purple}반짝이는 혼합물{}은 물속에서 이동 속도를 크게 높여 주므로, 수상 이동에 효과적입니다.

;;;;;

<recipe;things:enchanted_wax_gland>

다만 열에는 약합니다. [하데스 수정](^things:trinkets/hades_crystal)을 함께 착용하면 이 약점을 보완할 수 있습니다.
