```json
{
  "icon": "things:rabbit_foot_charm",
  "title": "토끼발 부적",
  "category": "things:trinkets",
  "associated_items": [
    "things:rabbit_foot_charm"
  ]
}
```

보통 토끼발 장식은 행운을 가져다준다고 하지만, {light_purple}반짝이는 가루{}를 뿌리면 다른 효과가 생깁니다. 가루가 물약 재료로 쓰이는 {light_purple}토끼발{}의 성질을 자극해 착용자에게 지속적인 {gold}점프 강화 II{} 효과를 제공합니다.

;;;;;

<recipe;things:rabbit_foot_charm>
