```json
{
  "icon": "things:arm_extender",
  "title": "팔 연장기",
  "category": "things:trinkets",
  "associated_items": [
    "things:arm_extender"
  ]
}
```

Minecraft에서 적을 때리거나 돌을 부수는 일은 매우 흔하므로, {gold}공격·상호작용 범위가 늘어나면{} 일상이 한결 편해집니다. {light_purple}팔 연장기{}는 바로 이를 위한 장신구입니다. 팔 끝에 *아주 무거운 피스톤*을 매단 것과 비슷하며, {gold}공격·상호작용 범위를 두 블록 늘려 줍니다{}.

;;;;;

<recipe;things:arm_extender>
