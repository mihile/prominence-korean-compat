```json
{
  "icon": "things:ender_pouch",
  "title": "엔더 주머니",
  "category": "things:trinkets",
  "associated_items": [
    "things:ender_pouch"
  ]
}
```

탐험 중 인벤토리가 가득 차서 일찍 돌아와야 하는 일은 누구나 겪어 봤을 것입니다. 간단한 재료만으로 해결하기는 어렵지만, {light_purple}엔더 주머니{}가 있으면 훨씬 오래 모험할 수 있습니다. 휴대용 엔더 상자처럼 작동하며, 자신의 {gold}엔더 상자 보관함{}을 빠르게 열 수 있습니다.

;;;;;

<recipe;things:ender_pouch>
