```json
{
  "icon": "things:item_magnet",
  "title": "아이템 자석",
  "category": "things:items",
  "associated_items": [
    "things:item_magnet"
  ]
}
```

{light_purple}아이템 자석{}은 흩어진 물건을 치우거나 슬쩍 가져올 때 유용합니다. {gold}우클릭{}하면 광선을 발사하고, 내장된 엔더 진주를 이용해 광선 주변의 모든 아이템을 사용자에게 순간이동시킵니다.

;;;;;

<recipe;things:item_magnet>

충전량을 너무 많이 소모하면 잠시 동안 수집 범위와 충전 속도가 크게 줄어드므로 주의해야 합니다.
