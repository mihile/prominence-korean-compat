```json
{
  "icon": "things:gleaming_ore",
  "title": "반짝이는 광석",
  "associated_items": [
    "things:gleaming_ore",
    "things:deepslate_gleaming_ore"
  ]
}
```

{light_purple}반짝이는 광석{}은 대부분의 {gold}Things 아이템{}을 만들 때 필요한 중요한 재료입니다. 서로 다른 돌이 맞닿는 지하 깊은 곳에서 발견할 수 있으며, [반짝이는 가루](^things:items/gleaming_materials)를 얻으려면 최소한 {light_purple}다이아몬드 곡괭이{}로 캐야 합니다. 광석이 부족하다면 {gold}행운{} 마법 부여가 도움이 되지만, 기대만큼 많이 나오지는 않을 수도 있습니다.

;;;;;

![](things:textures/gui/gleaming_ore_patchouli.png,fit)

자연에서 발견한 {light_purple}반짝이는 광석{}입니다. *{#999999}빛이 납니다{}*
