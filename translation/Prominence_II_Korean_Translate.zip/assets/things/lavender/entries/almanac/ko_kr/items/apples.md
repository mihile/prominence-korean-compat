```json
{
  "icon": "minecraft:apple",
  "title": "사과",
  "category": "things:items",
  "associated_items": [
    "minecraft:apple"
  ]
}
```

사과는 플레이어가 먹을 수 있는 음식입니다.

단축바에서 사과를 선택한 뒤 사용 버튼을 길게 누르거나, 그냥 입에 넣으면 됩니다. 사과 하나를 먹으면 허기 4와 포화도 2.4가 회복됩니다.

퇴비통에 사과를 넣으면 65% (13⁄20)의 확률로 퇴비 단계가 1만큼 올라갑니다.

;;;;;

![](things:textures/gui/apple_patchouli.png,fit)

{#ff0000}사과{}를 올바르게 설치하는 방법
